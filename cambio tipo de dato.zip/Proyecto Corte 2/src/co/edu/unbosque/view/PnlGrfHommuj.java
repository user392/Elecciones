package co.edu.unbosque.view;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PnlGrfHommuj extends JPanel {

	private JButton atras, boton_validar;
	private JPanel pnl_1, pnl_2, pnl_3, pnl_4, pnl_5, pnl_6, pnl_r1, pnl_r2, pnl_r3, pnl_r4, pnl_r5, pnl_r6;

	private JLabel label_Col1, label_Col2, label_Col3, label_Col4, label_Col5, label_Col6, label_Dep1, label_Dep2,
			label_Dep3, label_Dep4, label_Dep5, label_Dep6, label_Mun1, label_Mun2, label_Mun3, label_Mun4, label_Mun5,
			label_Mun6, label_Vot1, label_Vot2, label_Vot3, label_Vot4, label_Vot5, label_Vot6;

	private JComboBox<Object> combobox;

	public PnlGrfHommuj() {
		setLayout(null);
		setBackground(Color.white);

		IniciarComponentes();

		setVisible(false);
	}

	public void IniciarComponentes() {

		label_Col1 = new JLabel();
		label_Col1.setBounds(0, 0, 300, 225);
		add(label_Col1);

		label_Col2 = new JLabel();
		label_Col2.setBounds(300, 0, 300, 225);
		add(label_Col2);

		label_Col3 = new JLabel();
		label_Col3.setBounds(600, 0, 300, 225);
		add(label_Col3);

		label_Col4 = new JLabel();
		label_Col4.setBounds(0, 225, 300, 225);
		add(label_Col4);

		label_Col5 = new JLabel();
		label_Col5.setBounds(300, 225, 300, 225);
		add(label_Col5);

		label_Col6 = new JLabel();
		label_Col6.setBounds(600, 225, 300, 225);
		add(label_Col6);

		// Paneles Colombia
		pnl_1 = new JPanel();
		pnl_1.setBounds(0, 0, 300, 225);
		add(pnl_1);

		pnl_2 = new JPanel();
		pnl_2.setBounds(300, 0, 300, 225);
		add(pnl_2);

		pnl_3 = new JPanel();
		pnl_3.setBounds(600, 0, 300, 225);
		add(pnl_3);

		pnl_4 = new JPanel();
		pnl_4.setBounds(0, 225, 300, 225);
		add(pnl_4);

		pnl_5 = new JPanel();
		pnl_5.setBounds(300, 225, 300, 225);
		add(pnl_5);

		pnl_6 = new JPanel();
		pnl_6.setBounds(600, 225, 300, 225);
		add(pnl_6);

		// Resto
		pnl_r1 = new JPanel();
		pnl_r1.setBounds(0, 50, 300, 200);
		add(pnl_r1);

		pnl_r2 = new JPanel();
		pnl_r2.setBounds(300, 50, 300, 200);
		add(pnl_r2);

		pnl_r3 = new JPanel();
		pnl_r3.setBounds(600, 50, 300, 200);
		add(pnl_r3);

		pnl_r4 = new JPanel();
		pnl_r4.setBounds(0, 250, 300, 200);
		add(pnl_r4);

		pnl_r5 = new JPanel();
		pnl_r5.setBounds(300, 250, 300, 200);
		add(pnl_r5);

		pnl_r6 = new JPanel();
		pnl_r6.setBounds(600, 250, 300, 200);
		add(pnl_r6);

		atras = new JButton("Atras");
		atras.setBackground(Color.ORANGE);
		atras.setSize(120, 30);
		atras.setLocation(761, 468);
		add(atras);

		// Departamento
		label_Dep1 = new JLabel();
		label_Dep1.setBounds(0, 50, 300, 200);
		add(label_Dep1);

		label_Dep2 = new JLabel();
		label_Dep2.setBounds(300, 50, 300, 200);
		add(label_Dep2);

		label_Dep3 = new JLabel();
		label_Dep3.setBounds(600, 50, 300, 200);
		add(label_Dep3);

		label_Dep4 = new JLabel();
		label_Dep4.setBounds(0, 250, 300, 200);
		add(label_Dep4);

		label_Dep5 = new JLabel();
		label_Dep5.setBounds(300, 250, 300, 200);
		add(label_Dep5);

		label_Dep6 = new JLabel();
		label_Dep6.setBounds(600, 250, 300, 200);
		add(label_Dep6);

		// Municipio
		label_Mun1 = new JLabel();
		label_Mun1.setBounds(0, 50, 300, 200);
		add(label_Mun1);

		label_Mun2 = new JLabel();
		label_Mun2.setBounds(300, 50, 300, 200);
		add(label_Mun2);

		label_Mun3 = new JLabel();
		label_Mun3.setBounds(600, 50, 300, 200);
		add(label_Mun3);

		label_Mun4 = new JLabel();
		label_Mun4.setBounds(0, 250, 300, 200);
		add(label_Mun4);

		label_Mun5 = new JLabel();
		label_Mun5.setBounds(300, 250, 300, 200);
		add(label_Mun5);

		label_Mun6 = new JLabel();
		label_Mun6.setBounds(600, 250, 300, 200);
		add(label_Mun6);

		// Puesto de Votacion
		label_Vot1 = new JLabel();
		label_Vot1.setBounds(0, 50, 300, 200);
		add(label_Vot1);

		label_Vot2 = new JLabel();
		label_Vot2.setBounds(300, 50, 300, 200);
		add(label_Vot2);

		label_Vot3 = new JLabel();
		label_Vot3.setBounds(600, 50, 300, 200);
		add(label_Vot3);

		label_Vot4 = new JLabel();
		label_Vot4.setBounds(0, 250, 300, 200);
		add(label_Vot4);

		label_Vot5 = new JLabel();
		label_Vot5.setBounds(300, 250, 300, 200);
		add(label_Vot5);

		label_Vot6 = new JLabel();
		label_Vot6.setBounds(600, 250, 300, 200);
		add(label_Vot6);

		combobox = new JComboBox<Object>();
		combobox.setBounds(300, 5, 150, 30);
		combobox.setBackground(Color.white);
		add(combobox);

		boton_validar = new JButton("Validar");
		boton_validar.setBounds(550, 5, 150, 30);
		boton_validar.setBackground(Color.white);
		add(boton_validar);

	}

	public JButton getAtras() {
		return atras;
	}

	public void setAtras(JButton atras) {
		this.atras = atras;
	}

	public JPanel getPnl_Col1() {
		return pnl_1;
	}

	public void setPnl_Col1(JPanel pnl_Col1) {
		this.pnl_1 = pnl_Col1;
	}

	public JPanel getPnl_Col2() {
		return pnl_2;
	}

	public void setPnl_Col2(JPanel pnl_Col2) {
		this.pnl_2 = pnl_Col2;
	}

	public JPanel getPnl_Col3() {
		return pnl_3;
	}

	public void setPnl_Col3(JPanel pnl_Col3) {
		this.pnl_3 = pnl_Col3;
	}

	public JPanel getPnl_Col4() {
		return pnl_4;
	}

	public void setPnl_Col4(JPanel pnl_Col4) {
		this.pnl_4 = pnl_Col4;
	}

	public JPanel getPnl_Col5() {
		return pnl_5;
	}

	public void setPnl_Col5(JPanel pnl_Col5) {
		this.pnl_5 = pnl_Col5;
	}

	public JPanel getPnl_Col6() {
		return pnl_6;
	}

	public void setPnl_Col6(JPanel pnl_Col6) {
		this.pnl_6 = pnl_Col6;
	}

	public JLabel getLabel_1() {
		return label_Col1;
	}

	public void setLabel_1(JLabel label_1) {
		this.label_Col1 = label_1;
	}

	public JPanel getPnl_1() {
		return pnl_1;
	}

	public void setPnl_1(JPanel pnl_1) {
		this.pnl_1 = pnl_1;
	}

	public JPanel getPnl_2() {
		return pnl_2;
	}

	public void setPnl_2(JPanel pnl_2) {
		this.pnl_2 = pnl_2;
	}

	public JPanel getPnl_3() {
		return pnl_3;
	}

	public void setPnl_3(JPanel pnl_3) {
		this.pnl_3 = pnl_3;
	}

	public JPanel getPnl_4() {
		return pnl_4;
	}

	public void setPnl_4(JPanel pnl_4) {
		this.pnl_4 = pnl_4;
	}

	public JPanel getPnl_5() {
		return pnl_5;
	}

	public void setPnl_5(JPanel pnl_5) {
		this.pnl_5 = pnl_5;
	}

	public JPanel getPnl_6() {
		return pnl_6;
	}

	public void setPnl_6(JPanel pnl_6) {
		this.pnl_6 = pnl_6;
	}

	public JLabel getLabel_2() {
		return label_Col2;
	}

	public void setLabel_2(JLabel label_2) {
		this.label_Col2 = label_2;
	}

	public JLabel getLabel_3() {
		return label_Col3;
	}

	public void setLabel_3(JLabel label_3) {
		this.label_Col3 = label_3;
	}

	public JLabel getLabel_4() {
		return label_Col4;
	}

	public void setLabel_4(JLabel label_4) {
		this.label_Col4 = label_4;
	}

	public JLabel getLabel_5() {
		return label_Col5;
	}

	public void setLabel_5(JLabel label_5) {
		this.label_Col5 = label_5;
	}

	public JLabel getLabel_6() {
		return label_Col6;
	}

	public void setLabel_6(JLabel label_6) {
		this.label_Col6 = label_6;
	}

	public JButton getBoton_validar() {
		return boton_validar;
	}

	public void setBoton_validar(JButton boton_validar) {
		this.boton_validar = boton_validar;
	}

	public JPanel getPnl_r1() {
		return pnl_r1;
	}

	public void setPnl_r1(JPanel pnl_r1) {
		this.pnl_r1 = pnl_r1;
	}

	public JPanel getPnl_r2() {
		return pnl_r2;
	}

	public void setPnl_r2(JPanel pnl_r2) {
		this.pnl_r2 = pnl_r2;
	}

	public JPanel getPnl_r3() {
		return pnl_r3;
	}

	public void setPnl_r3(JPanel pnl_r3) {
		this.pnl_r3 = pnl_r3;
	}

	public JPanel getPnl_r4() {
		return pnl_r4;
	}

	public void setPnl_r4(JPanel pnl_r4) {
		this.pnl_r4 = pnl_r4;
	}

	public JPanel getPnl_r5() {
		return pnl_r5;
	}

	public void setPnl_r5(JPanel pnl_r5) {
		this.pnl_r5 = pnl_r5;
	}

	public JPanel getPnl_r6() {
		return pnl_r6;
	}

	public void setPnl_r6(JPanel pnl_r6) {
		this.pnl_r6 = pnl_r6;
	}

	public JLabel getLabel_Col1() {
		return label_Col1;
	}

	public void setLabel_Col1(JLabel label_Col1) {
		this.label_Col1 = label_Col1;
	}

	public JLabel getLabel_Col2() {
		return label_Col2;
	}

	public void setLabel_Col2(JLabel label_Col2) {
		this.label_Col2 = label_Col2;
	}

	public JLabel getLabel_Col3() {
		return label_Col3;
	}

	public void setLabel_Col3(JLabel label_Col3) {
		this.label_Col3 = label_Col3;
	}

	public JLabel getLabel_Col4() {
		return label_Col4;
	}

	public void setLabel_Col4(JLabel label_Col4) {
		this.label_Col4 = label_Col4;
	}

	public JLabel getLabel_Col5() {
		return label_Col5;
	}

	public void setLabel_Col5(JLabel label_Col5) {
		this.label_Col5 = label_Col5;
	}

	public JLabel getLabel_Col6() {
		return label_Col6;
	}

	public void setLabel_Col6(JLabel label_Col6) {
		this.label_Col6 = label_Col6;
	}

	public JLabel getLabel_Dep1() {
		return label_Dep1;
	}

	public void setLabel_Dep1(JLabel label_Dep1) {
		this.label_Dep1 = label_Dep1;
	}

	public JLabel getLabel_Dep2() {
		return label_Dep2;
	}

	public void setLabel_Dep2(JLabel label_Dep2) {
		this.label_Dep2 = label_Dep2;
	}

	public JLabel getLabel_Dep3() {
		return label_Dep3;
	}

	public void setLabel_Dep3(JLabel label_Dep3) {
		this.label_Dep3 = label_Dep3;
	}

	public JLabel getLabel_Dep4() {
		return label_Dep4;
	}

	public void setLabel_Dep4(JLabel label_Dep4) {
		this.label_Dep4 = label_Dep4;
	}

	public JLabel getLabel_Dep5() {
		return label_Dep5;
	}

	public void setLabel_Dep5(JLabel label_Dep5) {
		this.label_Dep5 = label_Dep5;
	}

	public JLabel getLabel_Dep6() {
		return label_Dep6;
	}

	public void setLabel_Dep6(JLabel label_Dep6) {
		this.label_Dep6 = label_Dep6;
	}

	public JLabel getLabel_Mun1() {
		return label_Mun1;
	}

	public void setLabel_Mun1(JLabel label_Mun1) {
		this.label_Mun1 = label_Mun1;
	}

	public JLabel getLabel_Mun2() {
		return label_Mun2;
	}

	public void setLabel_Mun2(JLabel label_Mun2) {
		this.label_Mun2 = label_Mun2;
	}

	public JLabel getLabel_Mun3() {
		return label_Mun3;
	}

	public void setLabel_Mun3(JLabel label_Mun3) {
		this.label_Mun3 = label_Mun3;
	}

	public JLabel getLabel_Mun4() {
		return label_Mun4;
	}

	public void setLabel_Mun4(JLabel label_Mun4) {
		this.label_Mun4 = label_Mun4;
	}

	public JLabel getLabel_Mun5() {
		return label_Mun5;
	}

	public void setLabel_Mun5(JLabel label_Mun5) {
		this.label_Mun5 = label_Mun5;
	}

	public JLabel getLabel_Mun6() {
		return label_Mun6;
	}

	public void setLabel_Mun6(JLabel label_Mun6) {
		this.label_Mun6 = label_Mun6;
	}

	public JLabel getLabel_Vot1() {
		return label_Vot1;
	}

	public void setLabel_Vot1(JLabel label_Vot1) {
		this.label_Vot1 = label_Vot1;
	}

	public JLabel getLabel_Vot2() {
		return label_Vot2;
	}

	public void setLabel_Vot2(JLabel label_Vot2) {
		this.label_Vot2 = label_Vot2;
	}

	public JLabel getLabel_Vot3() {
		return label_Vot3;
	}

	public void setLabel_Vot3(JLabel label_Vot3) {
		this.label_Vot3 = label_Vot3;
	}

	public JLabel getLabel_Vot4() {
		return label_Vot4;
	}

	public void setLabel_Vot4(JLabel label_Vot4) {
		this.label_Vot4 = label_Vot4;
	}

	public JLabel getLabel_Vot5() {
		return label_Vot5;
	}

	public void setLabel_Vot5(JLabel label_Vot5) {
		this.label_Vot5 = label_Vot5;
	}

	public JLabel getLabel_Vot6() {
		return label_Vot6;
	}

	public void setLabel_Vot6(JLabel label_Vot6) {
		this.label_Vot6 = label_Vot6;
	}

	public JComboBox<Object> getCombobox() {
		return combobox;
	}

	public void setCombobox(JComboBox<Object> combobox) {
		this.combobox = combobox;
	}

}