package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.omg.CORBA.FREE_MEM;

import co.edu.unbosque.model.FechaNacimientoExcepcion;
import co.edu.unbosque.model.FechasExcepcion;
import co.edu.unbosque.model.NombresExcepcion;
import co.edu.unbosque.model.NumeroCedulaExcepcion;
import co.edu.unbosque.model.Persona;
import co.edu.unbosque.model.persistence.ArchivoBinario;
import co.edu.unbosque.model.persistence.Persistencia;
import co.edu.unbosque.view.VtnPrincipal;

public class Controller implements ActionListener {
	private List<String> arregloDepartamento = new ArrayList<String>();
	private List<String> arregloCiudad = new ArrayList<String>();
	private List<String> arregloPuesto = new ArrayList<String>();
	private List<String> arregloDireccion = new ArrayList<String>();
	private List<String> arreglo_ciudades2 = new ArrayList<String>();

	private ArrayList<Persona> arregloVotantes = new ArrayList<Persona>();
	private static final String SAMPLE_CSV_FILE_PATH = "Puestos_de_votacion.csv";

	private Persona persona;
	private VtnPrincipal vtnPrincipal;

	String numeros = "[0-9]+";

	private Persistencia Persi;

	private ArchivoBinario ab;

	public Controller() {

		vtnPrincipal = new VtnPrincipal();

		Persi = new Persistencia();
		Persi.getAb().escribirArchivoBinario();
		ab = new ArchivoBinario();

		try (

				Reader reader = Files.newBufferedReader(Paths.get(SAMPLE_CSV_FILE_PATH), StandardCharsets.ISO_8859_1);
				CSVParser parser = CSVFormat.DEFAULT.withDelimiter(';').withHeader().parse(reader);

		) {
			for (CSVRecord csvRecord : parser) {

				String Departamento = csvRecord.get(0) + "";
				String Ciudad = csvRecord.get(1) + "";
				String Puesto = csvRecord.get(2) + "";
				String Direccion = csvRecord.get(3) + "";

				arregloDepartamento.add(Departamento);
				arregloCiudad.add(Ciudad);
				arregloPuesto.add(Puesto);
				arregloDireccion.add(Direccion);

				System.out.println(Departamento + "\t" + Ciudad + "\t" + Puesto + "\t" + Direccion);

			}
		} catch (IOException e) {

			e.printStackTrace();
		}

		// Guardar en un arraylist los valores de las ciudades sin duplicarse
		for (int i = 0; i < (arregloCiudad.size() - 1); i++) {
			if (!(arregloCiudad.get(i + 1).contains(arregloCiudad.get(i)))) {
				arreglo_ciudades2.add(arregloCiudad.get(i));

			}
		}

		for (int i = 0; i < arreglo_ciudades2.size(); i++) {
			vtnPrincipal.getPnlAddPer().getLugarNacimiento().addItem(arreglo_ciudades2.get(i));
			vtnPrincipal.getPnlAddPer().getLugarExpedicion().addItem(arreglo_ciudades2.get(i));
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////
		vtnPrincipal.getPnlInicio().getRegistrarCiu().addActionListener(this);
		vtnPrincipal.getPnlInicio().getBuscarCiu().addActionListener(this);
		vtnPrincipal.getPnlInicio().getGraficas().addActionListener(this);
		vtnPrincipal.getPnlInicio().getRegistrarCiu().addActionListener(this);
		vtnPrincipal.getPnlInicio().getListaInscritos().addActionListener(this);

		vtnPrincipal.getPnlAddPer().getVolver().addActionListener(this);
		vtnPrincipal.getPnlAddPer().getRegistrar().addActionListener(this);

		vtnPrincipal.getPnlBuscarPer().getVolver().addActionListener(this);

		vtnPrincipal.getPnlGraficas().getInsCol().addActionListener(this);
		vtnPrincipal.getPnlGraficas().getInsDep().addActionListener(this);
		vtnPrincipal.getPnlGraficas().getInsMun().addActionListener(this);
		vtnPrincipal.getPnlGraficas().getInsPuesto().addActionListener(this);
		vtnPrincipal.getPnlGraficas().getVolver().addActionListener(this);

		vtnPrincipal.getPnlGrfCol().getAtras().addActionListener(this);
		vtnPrincipal.getPnlGrfDep().getAtras().addActionListener(this);
		vtnPrincipal.getPnlGrfHommuj().getAtras().addActionListener(this);
		vtnPrincipal.getPnlGrfInscritos().getAtras().addActionListener(this);
		vtnPrincipal.getPnlGrfMun().getAtras().addActionListener(this);
		vtnPrincipal.getPnlGrfPuesto().getAtras().addActionListener(this);

		vtnPrincipal.getPnlListaInscritos().getVolver().addActionListener(this);

	}

	public void inscribir_Ciudadano() {

	}

	public String nombres(String n) throws NombresExcepcion {

		if (n.matches(numeros)) {
			throw new NumberFormatException("El formato del nombre o apellido es incorrecto");
		} else {
			return n;
		}
	}

	public String comprobarCedula(String c) throws NumeroCedulaExcepcion {

		if (c.matches(numeros) && (c.length() >= 5 && c.length() <= 10)) {
			return c;
		} else {
			throw new NumeroCedulaExcepcion("El formato de la c�dula es incorrecto");
		}
	}

	public char genero() throws NullPointerException {

		if (vtnPrincipal.getPnlAddPer().getSexo().getSelectedItem() == "Masculino") {
			return 'M';
		} else if (vtnPrincipal.getPnlAddPer().getSexo().getSelectedItem() == "Femenino") {
			return 'F';
		} else {
			throw new NullPointerException("No se ha seleccionado un g�nero");
		}
	}

	public String fNacimiento(Date n) throws FechaNacimientoExcepcion {

		SimpleDateFormat year = new SimpleDateFormat("yyyy");

		String n1 = year.format(n);
		int int_n1 = Integer.parseInt(n1);

		LocalDate now = LocalDate.now();

		if ((now.getYear() - int_n1) >= 18) {
			return n1;
		} else {
			throw new FechaNacimientoExcepcion("La fecha de nacimiento ingresada muestra que no es mayor de edad");
		}
	}

	public void fechas(Date n, Date e) throws FechasExcepcion {

		SimpleDateFormat year = new SimpleDateFormat("yyyy");

		String dateE = year.format(e);
		String dateN = year.format(n);

		int diferencia = Integer.parseInt(dateE) - Integer.parseInt(dateN);

		if (diferencia >= 18) {

		} else if (diferencia < 0) {
			throw new FechasExcepcion("La fecha de nacimiento debe de ser antes que la fecha de expedicion");
		} else {
			throw new FechasExcepcion(
					"La fecha de nacimiento tiene que tener por lo menos 18 a�os de diferencia a la fecha de expedicion");
		}

	}

	public void buscar_Ciudadano() {

	}

	public void eliminar_Ciudadano() {

	}

	public void asignarPuestoVotacion() {

	}

	public void modificar_Ciudadano() {

	}

	public void calcularEstadisticasColombia_18_25() {

		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Hombres", new Double(40));
		dataset.setValue("Mujeres", new Double(60));

		JFreeChart chart = ChartFactory.createPieChart("Inscritos en Colombia: Rango 1", dataset, true, true, false);

		BufferedImage graficoTorta = chart.createBufferedImage(vtnPrincipal.getPnlGrfHommuj().getPnl_1().getWidth(),
				vtnPrincipal.getPnlGrfHommuj().getPnl_1().getHeight());

		vtnPrincipal.getPnlGrfHommuj().getLabel_1().setIcon(new ImageIcon(graficoTorta));
		vtnPrincipal.getPnlGrfHommuj().getPnl_1().updateUI();

	}

	public void calcularEstadisticasColombia_26_29() {

		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Hombres", new Double(30));
		dataset.setValue("Mujeres", new Double(60));

		JFreeChart chart = ChartFactory.createPieChart("Inscritos en Colombia: Rango 2", dataset, true, true, false);

		BufferedImage graficoTorta = chart.createBufferedImage(vtnPrincipal.getPnlGrfHommuj().getPnl_2().getWidth(),
				vtnPrincipal.getPnlGrfHommuj().getPnl_2().getHeight());

		vtnPrincipal.getPnlGrfHommuj().getLabel_2().setIcon(new ImageIcon(graficoTorta));
		vtnPrincipal.getPnlGrfHommuj().getPnl_2().updateUI();

	}

	public void calcularEstadisticasColombia_30_37() {

		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Hombres", new Double(20));
		dataset.setValue("Mujeres", new Double(25));

		JFreeChart chart = ChartFactory.createPieChart("Inscritos en Colombia: Rango 3", dataset, true, true, false);

		BufferedImage graficoTorta = chart.createBufferedImage(vtnPrincipal.getPnlGrfHommuj().getPnl_3().getWidth(),
				vtnPrincipal.getPnlGrfHommuj().getPnl_3().getHeight());

		vtnPrincipal.getPnlGrfHommuj().getLabel_3().setIcon(new ImageIcon(graficoTorta));
		vtnPrincipal.getPnlGrfHommuj().getPnl_3().updateUI();

	}

	public void calcularEstadisticasColombia_38_49() {

		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Hombres", new Double(40));
		dataset.setValue("Mujeres", new Double(60));

		JFreeChart chart = ChartFactory.createPieChart("Inscritos en Colombia: Rango 4", dataset, true, true, false);

		BufferedImage graficoTorta = chart.createBufferedImage(vtnPrincipal.getPnlGrfHommuj().getPnl_4().getWidth(),
				vtnPrincipal.getPnlGrfHommuj().getPnl_4().getHeight());

		vtnPrincipal.getPnlGrfHommuj().getLabel_4().setIcon(new ImageIcon(graficoTorta));
		vtnPrincipal.getPnlGrfHommuj().getPnl_4().updateUI();

	}

	public void calcularEstadisticasColombia_50_66() {

		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Hombres", new Double(40));
		dataset.setValue("Mujeres", new Double(60));

		JFreeChart chart = ChartFactory.createPieChart("Inscritos en Colombia: Rango 5", dataset, true, true, false);

		BufferedImage graficoTorta = chart.createBufferedImage(vtnPrincipal.getPnlGrfHommuj().getPnl_5().getWidth(),
				vtnPrincipal.getPnlGrfHommuj().getPnl_5().getHeight());

		vtnPrincipal.getPnlGrfHommuj().getLabel_5().setIcon(new ImageIcon(graficoTorta));
		vtnPrincipal.getPnlGrfHommuj().getPnl_5().updateUI();

	}

	public void calcularEstadisticasColombia_67() {

		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Hombres", new Double(40));
		dataset.setValue("Mujeres", new Double(60));

		JFreeChart chart = ChartFactory.createPieChart("Inscritos en Colombia: Rango 6", dataset, true, true, false);

		BufferedImage graficoTorta = chart.createBufferedImage(vtnPrincipal.getPnlGrfHommuj().getPnl_6().getWidth(),
				vtnPrincipal.getPnlGrfHommuj().getPnl_6().getHeight());

		vtnPrincipal.getPnlGrfHommuj().getLabel_6().setIcon(new ImageIcon(graficoTorta));
		vtnPrincipal.getPnlGrfHommuj().getPnl_6().updateUI();

	}

	public void calcularEstadisticasDepartamento_18_25() {

	}

	public void calcularEstadisticasDepartamento_26_29() {

	}

	public void calcularEstadisticasDepartamento_30_37() {

	}

	public void calcularEstadisticasDepartamento_38_49() {

	}

	public void calcularEstadisticasDepartamento_50_66() {

	}

	public void calcularEstadisticasDepartamento_67() {

	}

	public void calcularEstadisticasMunicipio_18_25() {

	}

	public void calcularEstadisticasMunicipio_26_29() {

	}

	public void calcularEstadisticasMunicipio_30_37() {

	}

	public void calcularEstadisticasMunicipio_38_49() {

	}

	public void calcularEstadisticasMunicipio_50_66() {

	}

	public void calcularEstadisticasMunicipio_67() {

	}

	public void calcularEstadisticasPuestoVotacion_18_25() {

	}

	public void calcularEstadisticasPuestoVotacion_26_29() {

	}

	public void calcularEstadisticasPuestoVotacion_30_37() {

	}

	public void calcularEstadisticasPuestoVotacion_38_49() {

	}

	public void calcularEstadisticasPuestoVotacion_50_66() {

	}

	public void calcularEstadisticasPuestoVotacion_67() {

	}

	private void mostrarRegistros() {

		for (int i = 0; i < 1; i++) {

			vtnPrincipal.getPnlListaInscritos().getTxtnombre1()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getPrimerNombre()) + "\n");
			vtnPrincipal.getPnlListaInscritos().getTxtnombre2()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getSegundoNombre()) + "\n");
			vtnPrincipal.getPnlListaInscritos().getTxtapellido1()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getPrimerApellido()) + "\n");
			vtnPrincipal.getPnlListaInscritos().getTxtapellido2()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getSegundoApellido()) + "\n");
			vtnPrincipal.getPnlListaInscritos().getTxtcedula()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getCedula()) + "\n");
			vtnPrincipal.getPnlListaInscritos().getTxtsexo()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getSexo()) + "\n");
			vtnPrincipal.getPnlListaInscritos().getTxtfechanacimiento()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getFechaDeNacimiento()) + "\n");
			vtnPrincipal.getPnlListaInscritos().getTxtfechaExpedicion()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getFechaExpedicionCedula()) + "\n");
			vtnPrincipal.getPnlListaInscritos().getTxtlugarNacimiento()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getLugarDeNacimiento()) + "\n");
			vtnPrincipal.getPnlListaInscritos().getTxtlugarexpedicion()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getLugarExpedicionCedula()) + "\n");
			vtnPrincipal.getPnlListaInscritos().getTxtpuestodevotacion()
					.append(String.valueOf(Persi.getAb().getDatos()[i].getPuestodevotacion()) + "\n");

		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getActionCommand().equals("Registrar Ciudadano")) {
			vtnPrincipal.getPnlAddPer().setVisible(true);
			vtnPrincipal.getPnlBuscarPer().setVisible(false);
			vtnPrincipal.getPnlGraficas().setVisible(false);
			vtnPrincipal.getPnlInicio().setVisible(false);
			vtnPrincipal.getPnlListaInscritos().setVisible(false);

		}

		if (e.getActionCommand().equals("Buscar Ciudadano")) {
			vtnPrincipal.getPnlAddPer().setVisible(false);
			vtnPrincipal.getPnlBuscarPer().setVisible(true);
			vtnPrincipal.getPnlGraficas().setVisible(false);
			vtnPrincipal.getPnlInicio().setVisible(false);
			vtnPrincipal.getPnlGrfHommuj().setVisible(false);
			vtnPrincipal.getPnlListaInscritos().setVisible(false);

		}

		if (e.getActionCommand().equals("Graficas")) {
			vtnPrincipal.getPnlAddPer().setVisible(false);
			vtnPrincipal.getPnlBuscarPer().setVisible(false);
			vtnPrincipal.getPnlGraficas().setVisible(true);
			vtnPrincipal.getPnlInicio().setVisible(false);
			vtnPrincipal.getPnlGrfHommuj().setVisible(false);
			vtnPrincipal.getPnlListaInscritos().setVisible(false);

		}

		if (e.getActionCommand().equals("Lista de Inscritos")) {

			vtnPrincipal.getPnlAddPer().setVisible(false);
			vtnPrincipal.getPnlBuscarPer().setVisible(false);
			vtnPrincipal.getPnlGraficas().setVisible(false);
			vtnPrincipal.getPnlInicio().setVisible(false);
			vtnPrincipal.getPnlGrfHommuj().setVisible(false);
			vtnPrincipal.getPnlGrfCol().setVisible(false);
			vtnPrincipal.getPnlListaInscritos().setVisible(true);
			vtnPrincipal.getPnlGrfInscritos().setVisible(false);
			vtnPrincipal.getPnlGrfCol().setVisible(false);
			vtnPrincipal.getPnlGrfDep().setVisible(false);
			vtnPrincipal.getPnlGrfMun().setVisible(false);
			vtnPrincipal.getPnlGrfPuesto().setVisible(false);

			Persi.getAb().leerRegistro();
			mostrarRegistros();

		}

		if (e.getActionCommand().equals("Inscritos-Colombia")) {
			vtnPrincipal.getPnlAddPer().setVisible(false);
			vtnPrincipal.getPnlBuscarPer().setVisible(false);
			vtnPrincipal.getPnlGraficas().setVisible(false);
			vtnPrincipal.getPnlInicio().setVisible(false);
			vtnPrincipal.getPnlGrfHommuj().setVisible(true);
			vtnPrincipal.getPnlListaInscritos().setVisible(false);

			calcularEstadisticasColombia_18_25();
			calcularEstadisticasColombia_26_29();
			calcularEstadisticasColombia_30_37();
			calcularEstadisticasColombia_38_49();
			calcularEstadisticasColombia_50_66();
			calcularEstadisticasColombia_67();
			
			vtnPrincipal.getPnlGrfHommuj().getCombobox().setVisible(false);
			vtnPrincipal.getPnlGrfHommuj().getBoton_validar().setVisible(false);

		}

		if (e.getActionCommand().equals("Inscritos-Departamento")) {
			vtnPrincipal.getPnlAddPer().setVisible(false);
			vtnPrincipal.getPnlBuscarPer().setVisible(false);
			vtnPrincipal.getPnlGraficas().setVisible(false);
			vtnPrincipal.getPnlInicio().setVisible(false);
			vtnPrincipal.getPnlGrfHommuj().setVisible(true);
			vtnPrincipal.getPnlListaInscritos().setVisible(false);

		}
		
		if (e.getActionCommand().equals("Inscritos-Municipio")) {
			vtnPrincipal.getPnlAddPer().setVisible(false);
			vtnPrincipal.getPnlBuscarPer().setVisible(false);
			vtnPrincipal.getPnlGraficas().setVisible(false);
			vtnPrincipal.getPnlInicio().setVisible(false);
			vtnPrincipal.getPnlGrfHommuj().setVisible(true);
			vtnPrincipal.getPnlListaInscritos().setVisible(false);

		}
		if (e.getActionCommand().equals("Inscritos-Puesto")) {
			vtnPrincipal.getPnlAddPer().setVisible(false);
			vtnPrincipal.getPnlBuscarPer().setVisible(false);
			vtnPrincipal.getPnlGraficas().setVisible(false);
			vtnPrincipal.getPnlInicio().setVisible(false);
			vtnPrincipal.getPnlGrfHommuj().setVisible(true);
			vtnPrincipal.getPnlListaInscritos().setVisible(false);

		}

		if (e.getActionCommand().equals("Regresar")) {
			vtnPrincipal.getPnlAddPer().setVisible(false);
			vtnPrincipal.getPnlBuscarPer().setVisible(false);
			vtnPrincipal.getPnlGraficas().setVisible(false);
			vtnPrincipal.getPnlInicio().setVisible(true);
			vtnPrincipal.getPnlGrfHommuj().setVisible(false);
			vtnPrincipal.getPnlListaInscritos().setVisible(false);

		}

		if (e.getActionCommand().equals("Atras")) {
			vtnPrincipal.getPnlAddPer().setVisible(false);
			vtnPrincipal.getPnlBuscarPer().setVisible(false);
			vtnPrincipal.getPnlGraficas().setVisible(true);
			vtnPrincipal.getPnlInicio().setVisible(false);
			vtnPrincipal.getPnlGrfHommuj().setVisible(false);
			vtnPrincipal.getPnlListaInscritos().setVisible(false);

		}

		if (e.getActionCommand().equals("Registrar")) {

			String nombre1 = vtnPrincipal.getPnlAddPer().getIpnombre().getText();
			nombre1 = nombre1.replace(" ", "");

			String nombre2 = vtnPrincipal.getPnlAddPer().getIsnombre().getText();
			nombre2 = nombre2.replace(" ", "");

			String apellido1 = vtnPrincipal.getPnlAddPer().getIpapellido().getText();
			apellido1 = apellido1.replace(" ", "");

			String apellido2 = vtnPrincipal.getPnlAddPer().getIsapellido().getText();
			apellido2 = apellido2.replace(" ", "");

			String cedula = vtnPrincipal.getPnlAddPer().getIcedula().getText();
			cedula = cedula.replace(" ", "");

			String puestoVotacion = vtnPrincipal.getPnlAddPer().getIpuestodevotacion().getText();

			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");

			if (!nombre1.isEmpty() && !apellido1.isEmpty() && !apellido2.isEmpty() && !cedula.isEmpty()) {

				try {

					comprobarCedula(cedula);
					fechas(vtnPrincipal.getPnlAddPer().getCalendario().getDate(),
							vtnPrincipal.getPnlAddPer().getCalendarioExpedicion().getDate());
					fNacimiento(vtnPrincipal.getPnlAddPer().getCalendario().getDate());

					arregloVotantes.add(new Persona(nombres(nombre1), nombres(nombre2), nombres(apellido1),
							nombres(apellido2), comprobarCedula(cedula), genero(),
							df.format(vtnPrincipal.getPnlAddPer().getCalendario().getDate()),
							df.format(vtnPrincipal.getPnlAddPer().getCalendarioExpedicion().getDate()),
							vtnPrincipal.getPnlAddPer().getLugarNacimiento().getSelectedItem().toString(),
							vtnPrincipal.getPnlAddPer().getLugarExpedicion().getSelectedItem().toString(),
							puestoVotacion));

					vtnPrincipal.getPnlAddPer().setVisible(false);
					vtnPrincipal.getPnlBuscarPer().setVisible(false);
					vtnPrincipal.getPnlGraficas().setVisible(false);
					vtnPrincipal.getPnlInicio().setVisible(true);
					vtnPrincipal.getPnlListaInscritos().setVisible(false);

//					Persi.getAb().escribirRegistro(nombre1, nombre2, apellido1, apellido2, cedula, genero(),
//							FechaNacimiento, FechaExpedicion, mlugarNacimiento, mlugarExpedicionCedula,
//							mpuestovotacion);

				} catch (NumeroCedulaExcepcion e2) {
					JOptionPane.showMessageDialog(null, e2.getMessage());
				} catch (NullPointerException e2) {
					JOptionPane.showMessageDialog(null, e2.getMessage());
				} catch (NumberFormatException e2) {
					JOptionPane.showMessageDialog(null, e2.getMessage());
				} catch (NombresExcepcion e2) {
					JOptionPane.showMessageDialog(null, e2.getMessage());
				} catch (FechasExcepcion e2) {
					JOptionPane.showMessageDialog(null, e2.getMessage());
				} catch (FechaNacimientoExcepcion e2) {
					JOptionPane.showMessageDialog(null, e2.getMessage());
				}

			} else {
				JOptionPane.showMessageDialog(null,
						"Debes agregar toda la informacion solicitados para agregar un nuevo contacto", "Advertencia",
						JOptionPane.WARNING_MESSAGE);
			}

		}

	}

}
