package co.edu.unbosque.model.persistence;

import java.io.IOException;
import java.util.ArrayList;

import co.edu.unbosque.model.Persona;

public class PersonaDAO {

	
	private ArchivoBinario archivo;

	public PersonaDAO(ArchivoBinario Parchivo) {
		
		
		
		archivo = Parchivo;
	

	}
	public String verPersonas(ArrayList<Persona> personas) {
		String texto = "";
		for (int i = 0; i < personas.size(); i++) {
			texto = texto.concat(personas.get(i).toString() + "\n");
		}
		return texto;
	}

	public Persona buscarPersona(String cedula, ArrayList<Persona> personas) {
		Persona encontrado = null;
		if (!personas.isEmpty()) {
			for (int i = 0; i < personas.size(); i++) {
				if (personas.get(i).getCedula().equals(cedula)) {
					encontrado = personas.get(i);
				}
			}
		}

		return encontrado;
	}

	public boolean agregarPersona(String primerNombre, String segundoNombre, String primerApellido, String segundoApellido,
			String cedula, String sexo, String fechaDeNacimiento, String fechaExpedicionCedula, String lugarDeNacimiento,
			String lugarExpedicionCedula, String puestodevotacion,ArrayList<Persona> personas) {

		Persona nuevo = new Persona(primerNombre, segundoNombre, primerApellido, segundoApellido, cedula, sexo,fechaDeNacimiento,
				fechaExpedicionCedula,lugarDeNacimiento, lugarExpedicionCedula, puestodevotacion);

		if (buscarPersona(cedula,personas) == null) {
			personas.add(nuevo);
			archivo.escribirArchivoBinario(personas);
			return true;
		} else {
			return false;
		}

	}

	public boolean eliminarPersona(String cedula , ArrayList<Persona> personas) {
		try {
			Persona p = buscarPersona(cedula, personas);
			personas.remove(p);
			
			archivo.getF().delete();
			archivo.getF().createNewFile();
			archivo.escribirArchivoBinario(personas);
			
			
			
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false; 	
		}

	}	
}
