package co.edu.unbosque.model;

public interface PuestoDeVotacion {

	String pais();

	String departamento();

	String municipio();

	String lugarVotacion();

	String direccion();

	String Consulado();

}