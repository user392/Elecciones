package co.edu.unbosque.model;

public class FechaNacimientoExcepcion extends Exception {

	public FechaNacimientoExcepcion() {

		super();
	}

	public FechaNacimientoExcepcion(String m) {

		super(m);
	}
}