package co.edu.unbosque.model;

import java.io.Serializable;

public class Persona implements Serializable {

	private static final long serialVersionUID = 1L;

	private String primerNombre;
	private String segundoNombre;
	private String primerApellido;
	private String segundoApellido;
	private String cedula;
	private String sexo;
	private String fechaDeNacimiento;
	private String fechaExpedicionCedula;
	private String lugarDeNacimiento;
	private String lugarExpedicionCedula;
	private String puestodevotacion;

	public Persona(String pPrimerNombre, String pSegundoNombre, String pPrimerApellido, String pSegundoApellido,
			String pCedula, String pSexo, String pFechaNacimiento, String pFechaExpedicionCedula, String pLugarNacimiento,
			String pLugarExpedicionCedula, String pPuestodevotacion) {

		primerNombre = pPrimerNombre;
		segundoNombre = pSegundoNombre;
		primerApellido = pPrimerApellido;
		segundoApellido = pSegundoApellido;
		cedula = pCedula;
		sexo = pSexo;
		fechaDeNacimiento = pFechaNacimiento;
		fechaExpedicionCedula = pFechaExpedicionCedula;
		lugarDeNacimiento = pLugarNacimiento;
		lugarExpedicionCedula = "";
		puestodevotacion = pPuestodevotacion;
	}

	public String getPrimerNombre() {
		return primerNombre;
	}

	public void setPrimerNombre(String primerNombre) {
		this.primerNombre = primerNombre;
	}

	public String getSegundoNombre() {
		return segundoNombre;
	}

	public void setSegundoNombre(String segundoNombre) {
		this.segundoNombre = segundoNombre;
	}

	public String getPrimerApellido() {
		return primerApellido;
	}

	public void setPrimerApellido(String primerApellido) {
		this.primerApellido = primerApellido;
	}

	public String getSegundoApellido() {
		return segundoApellido;
	}

	public void setSegundoApellido(String segundoApellido) {
		this.segundoApellido = segundoApellido;
	}

	public String getCedula() {
		return cedula;
	}

	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getFechaDeNacimiento() {
		return fechaDeNacimiento;
	}

	public void setFechaDeNacimiento(String fechaDeNacimiento) {
		this.fechaDeNacimiento = fechaDeNacimiento;
	}

	public String getFechaExpedicionCedula() {
		return fechaExpedicionCedula;
	}

	public void setFechaExpedicionCedula(String fechaExpedicionCedula) {
		this.fechaExpedicionCedula = fechaExpedicionCedula;
	}

	public String getLugarDeNacimiento() {
		return lugarDeNacimiento;
	}

	public void setLugarDeNacimiento(String lugarDeNacimiento) {
		this.lugarDeNacimiento = lugarDeNacimiento;
	}

	public String getLugarExpedicionCedula() {
		return lugarExpedicionCedula;
	}

	public void setLugarExpedicionCedula(String lugarExpedicionCedula) {
		this.lugarExpedicionCedula = lugarExpedicionCedula;
	}

	public String getPuestodevotacion() {
		return puestodevotacion;
	}

	public void setPuestodevotacion(String puestodevotacion) {
		this.puestodevotacion = puestodevotacion;
	}

}