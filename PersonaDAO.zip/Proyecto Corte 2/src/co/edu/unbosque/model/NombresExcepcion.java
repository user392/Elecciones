package co.edu.unbosque.model;

public class NombresExcepcion extends Exception {
	
	public NombresExcepcion() {
		super();
	}
	
	public NombresExcepcion(String mensaje) {
		super(mensaje);
	}

}
