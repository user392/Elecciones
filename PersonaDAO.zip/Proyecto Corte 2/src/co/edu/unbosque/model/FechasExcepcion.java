package co.edu.unbosque.model;

public class FechasExcepcion extends Exception {

	public FechasExcepcion() {
		super();
	}
	
	public FechasExcepcion(String mensaje) {
		super(mensaje);
	}
}
